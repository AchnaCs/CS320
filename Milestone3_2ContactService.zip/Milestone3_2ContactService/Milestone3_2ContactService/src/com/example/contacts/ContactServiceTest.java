package com.example.contacts;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setup() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);

        Assertions.assertEquals(contact, contactService.getContact("1"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");
        Contact contact2 = new Contact("1", "Jane", "Smith", "9876543210", "456 Elm St");

        contactService.addContact(contact1);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);
        contactService.deleteContact("1");

        Assertions.assertNull(contactService.getContact("1"));
    }

    //new to improve coverage
    @Test
    public void testDeleteNonExistingContact() {
        Assertions.assertDoesNotThrow(() -> {
            contactService.deleteContact("nonExistingId");
        });
    }

    @Test
    public void testUpdateContactFirstName() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);
        contactService.updateContactField("1", "firstName", "Jane");

        Contact updatedContact = contactService.getContact("1");
        Assertions.assertEquals("Jane", updatedContact.getFirstName());
    }

    @Test
    public void testUpdateContactLastName() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);
        contactService.updateContactField("1", "lastName", "Smith");

        Contact updatedContact = contactService.getContact("1");
        Assertions.assertEquals("Smith", updatedContact.getLastName());
    }

    @Test
    public void testUpdateContactPhone() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);
        contactService.updateContactField("1", "phone", "9876543210");

        Contact updatedContact = contactService.getContact("1");
        Assertions.assertEquals("9876543210", updatedContact.getPhone());
    }

    @Test
    public void testUpdateContactAddress() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);
        contactService.updateContactField("1", "address", "456 Elm St");

        Contact updatedContact = contactService.getContact("1");
        Assertions.assertEquals("456 Elm St", updatedContact.getAddress());
    }

    @Test
    public void testUpdateContactInvalidField() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        contactService.addContact(contact);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactField("1", "invalidField", "Value");
        });
    }

    @Test
    public void testUpdateContactNotFound() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactField("nonExistingId", "firstName", "Jane");
        });
    }
}
