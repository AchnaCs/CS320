/**
 * 
 */
/**
 * @author palla1hk
 *
 */
module Milestone3_2ContactService {
}