package com.example.contacts;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");

        Assertions.assertEquals("1", contact.getContactId());
        Assertions.assertEquals("Mary", contact.getFirstName());
        Assertions.assertEquals("Doe", contact.getLastName());
        Assertions.assertEquals("1234567890", contact.getPhone());
        Assertions.assertEquals("345 Main St", contact.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Mary", "Doe", "1234567890", "345 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Mary", "Doe", "1234567890", "345 Main St");
        });
    }

    @Test
    public void testInvalidFirstName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", null, "Doe", "1234567890", "345 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "MaryMaryMary", "Doe", "1234567890", "345 Main St");
        });
    }

    @Test
    public void testInvalidLastName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", null, "1234567890", "345 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", "DoeDoeDoeDoeDoe", "1234567890", "345 Main St");
        });
    }

    @Test
    public void testInvalidPhone() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", "Doe", null, "345 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", "Doe", "123456", "345 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", "Doe", "abcde", "345 Main St");
        });
    }

    @Test
    public void testInvalidAddress() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", "Doe", "1234567890", null);
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Mary", "Doe", "1234567890", "1234567890123456789012345678901");
        });
    }

 // Tests for New equals and hashCode methods for better test coverage
    @Test
    public void testContactEquality() {
        Contact contact1 = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");
        Contact contact2 = new Contact("1", "Jane", "Smith", "9876543210", "456 Elm St");
        Contact contact3 = new Contact("2", "John", "Doe", "5555555555", "789 Maple St");

        Assertions.assertEquals(contact1, contact2);
        Assertions.assertNotEquals(contact1, contact3);
    }

    @Test
    public void testContactHashCode() {
        Contact contact1 = new Contact("1", "Mary", "Doe", "1234567890", "345 Main St");
        Contact contact2 = new Contact("1", "Jane", "Smith", "9876543210", "456 Elm St");
        Contact contact3 = new Contact("2", "John", "Doe", "5555555555", "789 Maple St");

        Assertions.assertEquals(contact1.hashCode(), contact2.hashCode());
        Assertions.assertNotEquals(contact1.hashCode(), contact3.hashCode());
    }
}
